
# 导入必要的库
import json  # 用于处理 JSON 数据
import torch  # PyTorch，用于处理深度学习模型
import streamlit as st  # Streamlit，用于创建 Web 应用
from transformers import AutoModelForCausalLM, AutoTokenizer  # Transformers 库，用于加载预训练模型和分词器
from transformers.generation.utils import GenerationConfig  # 用于加载生成配置

# 设置 Streamlit 页面标题
st.set_page_config(page_title="Baichuan 2")
# 设置应用程序的主标题
st.title("Baichuan 2")

# 初始化模型和分词器的函数，并使用 Streamlit 的缓存资源，以避免每次刷新页面都重新加载模型
@st.cache_resource
def init_model():
    # 加载预训练模型
    model = AutoModelForCausalLM.from_pretrained(
        "baichuan-inc/Baichuan2-13B-Chat",  # 模型名称
        torch_dtype=torch.float16,  # 使用半精度浮点数，以减少显存占用
        device_map="auto",  # 自动选择可用的设备（如 GPU）
        trust_remote_code=True  # 允许从远程加载自定义代码
    )
    # 从预训练模型中加载生成配置
    model.generation_config = GenerationConfig.from_pretrained(
        "baichuan-inc/Baichuan2-13B-Chat"
    )
    # 加载分词器（用于将文本转换为模型可以理解的输入格式）
    tokenizer = AutoTokenizer.from_pretrained(
        "baichuan-inc/Baichuan2-13B-Chat",
        use_fast=False,  # 使用慢速分词器，因为模型需要特殊的分词行为
        trust_remote_code=True
    )
    return model, tokenizer  # 返回加载好的模型和分词器

# 清空聊天历史的函数
def clear_chat_history():
    del st.session_state.messages  # 删除会话状态中的消息记录

# 初始化聊天历史的函数
def init_chat_history():
    # 创建一个默认的初始聊天消息，表示聊天助手的问候语
    with st.chat_message("assistant", avatar='🤖'):
        st.markdown("您好，我是百川大模型，很高兴为您服务🥰")

    # 如果会话状态中已经存在消息记录，则显示这些消息
    if "messages" in st.session_state:
        for message in st.session_state.messages:
            avatar = '🧑‍💻' if message["role"] == "user" else '🤖'  # 根据消息的角色选择头像
            with st.chat_message(message["role"], avatar=avatar):
                st.markdown(message["content"])  # 显示消息内容
    else:
        st.session_state.messages = []  # 如果没有消息记录，初始化一个空列表

    return st.session_state.messages  # 返回消息列表

# 主程序入口
def main():
    # 初始化模型和分词器
    model, tokenizer = init_model()
    # 初始化聊天历史
    messages = init_chat_history()

    # 获取用户输入的消息（使用 Streamlit 提供的聊天输入框）
    if prompt := st.chat_input("Shift + Enter 换行, Enter 发送"):
        # 显示用户消息
        with st.chat_message("user", avatar='🧑‍💻'):
            st.markdown(prompt)
        # 将用户消息添加到消息列表中
        messages.append({"role": "user", "content": prompt})
        print(f"[user] {prompt}", flush=True)  # 在控制台打印用户的消息

        # 生成助手的回复
        with st.chat_message("assistant", avatar='🤖'):
            placeholder = st.empty()  # 创建一个占位符，用于动态更新助手的回复
            for response in model.chat(tokenizer, messages, stream=True):  # 使用模型生成回复，stream=True 表示逐步生成
                placeholder.markdown(response)  # 更新占位符的内容为模型生成的回复
                if torch.backends.mps.is_available():
                    torch.mps.empty_cache()  # 如果使用苹果 M1/M2 芯片，清空显存缓存
        # 将助手的回复添加到消息列表中
        messages.append({"role": "assistant", "content": response})
        print(json.dumps(messages, ensure_ascii=False), flush=True)  # 在控制台打印消息列表

        # 提供一个按钮，用于清空对话
        st.button("清空对话", on_click=clear_chat_history)

# 调用主程序
if __name__ == "__main__":
    main()


