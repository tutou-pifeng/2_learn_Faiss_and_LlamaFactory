import os

import faiss
import numpy as np
import time


np.random.seed(0)
data = np.random.rand(1000000, 256)
ids = np.arange(0, 1000000)
query_vector = np.random.rand(1, 256)


def test01():

    index = faiss.IndexFlatL2(256)
    index = faiss.IndexIDMap(index)
    # 添加向量
    index.add_with_ids(data, ids)
    # 搜索向量
    s = time.time()
    D, I = index.search(query_vector, k=2)
    print('time:', time.time() - s)
    print(D, I)

    faiss.write_index(index, 'flat.faiss')
    print(os.stat('flat.faiss').st_size)


def test02():

    index = faiss.IndexFlatL2(256)
    index = faiss.IndexIVFFlat(index, 256, 100)
    index.nprobe = 4
    index.train(data)
    index.add_with_ids(data, ids)
    s = time.time()
    D, I = index.search(query_vector, k=2)
    print('time:', time.time() - s)
    print(D, I)

    faiss.write_index(index, 'ivfflat.faiss')
    print(os.stat('ivfflat.faiss').st_size)


def test03():

    # 第一个参数：量化参数
    # 第二个参数：向量维度
    # 第三个参数：质心数量
    # 第四个参数：子空间数量（或称为段数）, 较大的值意味着将原始向量空间划分为更多的子空间进行量化，有助于减少量化误差，因为每个子空间都将被更精细地量化。
    # 第五个参数：量化码本中码字的位数，每个段聚类的数量（8位256），决定了每个量化码字的精度，位数越多，每个码字能够表示的信息就越多，量化误差就越小。
    quantizer = faiss.IndexFlatL2(256)
    index = faiss.IndexIVFPQ(quantizer, 256, 100, 256, 10)
    index.nprobe = 4
    index.train(data)
    index.add_with_ids(data, ids)
    # 搜索向量
    s = time.time()
    D, I = index.search(query_vector, k=2)
    print('time:', time.time() - s)
    print(D, I)

    faiss.write_index(index, 'ivfpq.faiss')
    print(os.stat('ivfpq.faiss').st_size)


if __name__ == '__main__':
    test01()
    test02()
    test03()